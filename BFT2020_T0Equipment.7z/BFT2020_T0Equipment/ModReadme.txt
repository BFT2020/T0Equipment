Changes made by this mod

-Progression
--Crafting limited to 1 and 2 quality levels for T0 equipment
--Note the normal perks still apply for buffs (perk Machine gunner for pipe machine gun as an example)

-Items
--Removed the ability to repair T0 equipment
--Removed the ability to add mods to T0 equipment
--adjusted modifiers from 6 quality levels to 2
--Changed ammo of pipe maching gun to 9mm and reduced damage
--Reduced durability of pipe machine gun
--Reduced the fire rate of the pipe machine gun
--Changed ammo of pipe pistol to 44cal and reduced damage
--Increasd stamina use of stone axes
--Removed special ammo types from bow, pistol, shotgun, rifle, and machine gun

Recipes
--Changed the tags on all T0 equipment to limit quality levels

-Loot
--Removed all T0 items from the loot tables
--Changed out quest reward bundles to parts

-Traders
--Removed all T0 items from traders
--Repaced T0 weapons with weapon parts